from django.shortcuts import render

# Create your views here.
# orders/views.py

from django.shortcuts import render, redirect
from .models import Order
from products.models import Product
from django.contrib.auth.decorators import login_required

@login_required
def checkout(request):
    cart = request.session.get('cart', [])
    total_price = sum(product['price'] for product in cart)

    if request.method == 'POST':
        # Create order logic
        order = Order.objects.create(user=request.user, total_price=total_price)
        for item in cart:
            product = Product.objects.get(id=item['id'])
            order.products.add(product)
        request.session['cart'] = []  # Empty the cart
        return redirect('order_summary', order_id=order.id)

    return render(request, 'orders/checkout.html', {'cart': cart, 'total_price': total_price})
# cart/utils.py or in orders/views.py
def get_cart_total(request):
    cart = request.session.get('cart', {})
    total = 0
    for item_id, item_data in cart.items():
        price = float(item_data['price'])
        quantity = int(item_data['quantity'])
        total += price * quantity
    return round(total, 2)
# orders/views.py
import qrcode
import io
import base64
from django.shortcuts import render
from .utils import get_cart_total  # import your utility if separate

def checkout(request):
    upi_id = "yourupi@bank"
    payee_name = "Your Store"
    amount = get_cart_total(request)

    if amount <= 0:
        return render(request, "orders/checkout.html", {"error": "Your cart is empty."})

    upi_url = f"upi://pay?pa={upi_id}&pn={payee_name}&am={amount}&cu=INR"

    # Generate QR code
    qr = qrcode.make(upi_url)
    buffer = io.BytesIO()
    qr.save(buffer, format='PNG')
    img_str = base64.b64encode(buffer.getvalue()).decode()

    return render(request, 'orders/checkout.html', {
        'upi_id': upi_id,
        'amount': amount,
        'qr_code': img_str,
    })
